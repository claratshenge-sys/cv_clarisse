# CV Flutter — Clarisse Lodi

Application Flutter de présentation du CV, de la famille et des coordonnées de Clarisse Lodi.

## Fonctionnalités
- Page de connexion
- Page d'accueil présentant le profil et le CV
- Page famille (exemples à remplacer par les vrais membres)
- Page contact
- Navigation par menu latéral et barre inférieure
- Thème rose et bleu

## Lancer le projet
1. Installer Flutter et l'extension Flutter dans Visual Studio Code.
2. Ouvrir le dossier `cv_flutter_clarisse` dans VS Code.
3. Dans le terminal, exécuter :
   ```bash
   flutter pub get
   flutter run
   ```

## Connexion de démonstration
- Identifiant : `clarisse`
- Mot de passe : `1234`

> Ces identifiants sont uniquement pour la démonstration du devoir. Ce formulaire ne constitue pas une authentification sécurisée.

## Informations à compléter
- Ajouter les expériences, compétences précises et centres d'intérêt.
- Les membres de la famille sont renseignés ; ajouter leurs photos si disponibles.
- Ajouter l'adresse physique et les liens de réseaux sociaux.

## Captures d'écran
Après avoir lancé l'application, prenez une capture de chacune des quatre pages (Connexion, Accueil/CV, Famille, Contact) et ajoutez-les ici, par exemple :

```text
screenshots/
  connexion.png
  accueil.png
  famille.png
  contact.png
```

Puis ajoutez les images dans ce README avec :
```markdown
![Page de connexion](screenshots/connexion.png)
![Accueil - CV](screenshots/accueil.png)
![Famille](screenshots/famille.png)
![Contact](screenshots/contact.png)
```
